<?php
return array(
    'name' => 'RosKassa',
    'description' => 'Оплата с помощью <a href="https://roskassa.net/" target="_blank">RosKassa</a>.',
    'logo' => 'img/ros_kassa16.png',
    'icon' => 'img/RosKassa.png',
    'version' => '1.0.0',
    'vendor' => '1248865',
);
